<!-- Footer -->
<footer class="main">
	&copy; <?php echo date('Y')?> | School Management System in PHP using CodeIgniter Web Framework |
    <strong>Developed by Md Riadul Islam, TMSS ICT</strong>
</footer>
